$ = function(selector) {
    if (selector.substr(0, 1) == '#') {
        return document.getElementById(selector.substr(1, selector.length)) || {
            style: {}
        };
    } else {
        return document.getElementsByTagName(selector) || {
            style: {}
        };
    }
};

var Event = {
    p_: window,
    click: function(obj) {
        if (document.all) {
            obj.click();
        } else {
            var evt = document.createEvent("MouseEvents");
            evt.initEvent("click", true, true);
            obj.dispatchEvent(evt);
        }
    },
    util_event: function(e, obj) {
        e.element = obj;
        if (!e.preventDefault) {
            e.preventDefault = function() {
                e.returnValue = false;
            }
        }
        if (!e.stop) {
            e.stopPropagation = function() {
                e.cancelBubble = true;
            }
        }
        return e;
    },
    proxy: function(func, obj) {
        var that = this;
        return function() {
            arguments[0] = that.util_event(arguments[0], obj);
            func.apply(Event.p_, arguments);
        }
    },
    bind: function(obj, event, func) {
        if (!obj) {
            return;
        }
        // if (obj.length > 0) {
        //     for (var i = 0; i < obj.length; i++) {
        //         this.bind(obj[i], event, func);
        //     }
        //     return;
        // }
        if (obj.addEventListener) {
            obj.addEventListener(event, this.proxy(func, obj), false);
        } else if (obj.attachEvent) {
            obj.attachEvent('on' + event, this.proxy(func, obj));
        }
    },
    load: function(cb) {
        var already = false;
        if (document.addEventListener) {
            already = true;
            this.bind(document, "DOMContentLoaded", cb);
        } else if (document.all && !window.opera) {
            document.write('<script type="text/javascript" id="content_loaded" defer="defer" src="javascript:void(0)"><\/script>');
            var content_loaded = document.getElementById("content_loaded")
            content_loaded.onreadystatechange = function() {
                if (this.readyState == "complete") {
                    already = true;
                    cb();
                }
            };
        }
        this.bind(window, 'load', function() {
            setTimeout(function() {
                if (!already) cb();
            }, 0);
        });
    }
}
Stats = {
    securityId: (function() {
        try {
            return external.twGetSecurityID(window);
        } catch (e) {}
        return false;
    })(),
    add: function(index) {
        if (this.securityId)
            external.StatAddValue(this.securityId, "navigator_error", index, 1);
    }
};
var Error = {};
Error.info = {
    parse: function() {
        if (location.search && location.search.length > 1) {
            var arr = location.search.substr(1).split('&');

            function urlDecode(url) {
                try {
                    url = decodeURIComponent(url);
                } catch (e) {
                    try {
                        url = decodeURI(url);
                    } catch (e) {}
                }
                return url;
            }

            function getSearchParam(param) {
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i].indexOf(param) == 0) return urlDecode(arr[i].substr(param.length));
                }
                return '';
            }

            this._error_url = getSearchParam('url=');
            this._error_type = getSearchParam('error=');
            this._error_referrer = getSearchParam('referrer=');

            var newEl = document.createElement('a');
            newEl.href = this._error_url;
            if (newEl.protocol == 'javascript:' || newEl.protocol == 'data:') {
                this._error_url = '';
            }
            var urls = decodeURIComponent(this._error_url).split("/");
            this._error_domain = urls[2];
            if (this._error_type.indexOf('http') == 0) {
                this._error_code = parseInt(this._error_type.replace('http', ''));
                if (this._error_type != 'http404') {
                    this._error_type = 'default';
                }
            }
            if (this._error_type.indexOf('connectionfailure_') == 0) {
                this._error_code = parseInt(this._error_type.replace('connectionfailure_', ''));
                this._error_type = 'connectionfailure';
            }
        }
    },
};
Error.layout = {
    render: function(error_type) {
        var fn = this['_render_' + error_type];
        if (!fn) {
            fn = this._render_default;
        }
        fn && fn.call(this);
    },
    _render_default: function() {
        Stats.add(4); // 4. 其他错误页展示次数
        document.title = "网页无法访问";
        this._render_include();
        // 默认显示错误码
        if (Error.info._error_code > 0)
            $('#error_type').innerHTML = Error.info._error_code;
        else
            $('#error_type').innerHTML = "网络错误";

        $('#error_header').innerHTML = "网页无法访问";
        $('#button_index').style.display = 'none';
        $('#button_network').style.display = 'none';

        // 初始化搜索框内容
        $('#search_keyword').value = 'site:' + Error.info._error_domain + ' ';
        $('#search-results').src = 'https://www.so.com/brw?u=http://' + Error.info._error_domain;
    },
    _render_connectionfailure: function() {
        Stats.add(1); // 1.资源不存在错误页展示次数
        // document.title = "网络连接错误";
        this._render_include();
        $('#error_header').innerHTML = "网络连接错误";
        // 网络错误
        //            $('#error_type').innerHTML = Error.info.__error_code;
        $('#error_type').innerHTML = Error.info._error_code;
        $('#error_detail').innerHTML = "请检查网络设置";
        $('#error_detail_has_netrepair').innerHTML = "请检查网络设置，可用”360断网急救箱“检查网络";
        // 初始化搜索框内容
        $('#search_keyword').value = Error.info._error_domain;

        $('#button_index').style.display = 'none';
        // $('#button_refresh').style.display = 'none';
    },
    _render_dnserror: function() {
        Stats.add(1); // DNS 无法解析 ，统计暂时和连接错误放在一起，和以前保持一致。
        // document.title = "域名解析错误";
        this._render_include();
        $('#error_header').innerHTML = "域名解析错误";
        $('#error_type').innerHTML = "105";
        $('#error_detail').innerHTML = "请检查域名拼写和网络设置";
        $('#error_detail_has_netrepair').innerHTML = "请检查域名拼写，或用“360断网急救箱”检查网络";
        // 初始化搜索框内容
        $('#search_keyword').value = Error.info._error_domain;

        $('#button_index').style.display = 'none';
        // $('#button_refresh').style.display = 'none';
    },
    _render_http404: function() {
        Stats.add(3); // 3. 404 错误也展示次数
        // document.title = "您访问的网页不存在";
        $('#error_header').innerHTML = "网页不存在或已被删除";
        $('#error_type').innerHTML = "404";
        $('#error_detail').innerHTML = "该网页可能已被网站管理员删除";
        this._render_include();

        // 初始化搜索框内容
        $('#search_keyword').value = 'site:' + Error.info._error_domain + ' ';
        $('#button_network').style.display = 'none';
        // $('#button_refresh').style.display = 'none';
    },
    _render_include: function() {

        // 点击搜索右侧下拉箭头
        Event.bind($('#button_slist'), 'click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var obj = $('#search_droplist');
            if (obj.style.display == 'block') {
                obj.style.display = 'none';
            } else {
                obj.style.display = 'block';
            }

        });

        // 刷新按钮
        Event.bind($('#button_refresh'), 'click', function(e) {
            Stats.add(5); // 5. 点击刷新按钮次数
            e.preventDefault();
            if (Error.info._error_url) {
                window.location = Error.info._error_url;
            } else {
                location.reload();
            }
        });

        // 去首页按钮
        Event.bind($('#button_index'), 'click', function(e) {
            e.preventDefault();
            Stats.add(10);
            window.location = "http://" + Error.info._error_domain
        });
        //  急救箱按钮
        Event.bind($('#button_network'), 'click', function(e) {
            e.preventDefault();
            Stats.add(7);
            var started = false;
            try {
                chrome.send('show_network_rescuer');
            } catch (e) {}
        });


        $('#hide-search-results').onclick = function(e) {
            if ($('#search-results').offsetHeight) {
                $('#search-results').style.display = 'none';
                e.target.innerHTML = '显示搜索结果';
                localStorage.hideSearchStatus = 1;
            } else {
                $('#search-results').style.display = 'block';
                e.target.innerHTML = '隐藏搜索结果';
                localStorage.hideSearchStatus = 0;
            }
            e.preventDefault();
        };
    },
    refresh_frame: function() {
        return;
    }
};

var iframeHeight, iframeReady = false;
window.addEventListener('message', function(e) {
    if (e.data.height) {
        iframeHeight = e.data.height;
        $('#errors_iframe').style.height = e.data.height + 'px';
        document.body.style.background = '#f0f0f0';
        iframeReady = true;
        iframeResize();
    }
}, false);

var resizeTimer;
function iframeResize() {
    if (iframeReady) {
        resizeTimer && clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function(){
            $('#errors_iframe').style.height = Math.max(iframeHeight, document.documentElement.clientHeight - 199) + 'px';
        }, 0);
    }
}

Event.bind(window, 'resize', iframeResize);

Event.p_ = Error;
Event.load(function() {
    try {
        Error.info.parse();
    } catch (e) {
        return;
    }
    window.initSearchBlock = function(errorType) {
        return function() {
            if (errorType.indexOf('connectionfailure_103') != 0) {
                $('#search-results-wrap').style.display = 'block';

                if (localStorage.hideSearchStatus == '1') {
                    $('#search-results').style.display = 'none';
                    $('#hide-search-results').innerHTML = '显示搜索结果';
                } else {
                    $('#search-results').style.display = 'block';
                    $('#hide-search-results').innerHTML = '隐藏搜索结果';
                }
            }
        };
    }(Error.info._error_type);

    Error.layout.render(Error.info._error_type);
    // Error.layout.refresh_frame();

    chrome.send && chrome.send('check_show_network_rescuer_button');

    var sct = document.createElement('script');
    sct.src = 'http://errsug.se.360.cn/errsug7_new.js?' + (+new Date());
    document.body.appendChild(sct);
});


function showNetworkRescuerButton() {
    //network button is hidden on init in case that 360NetRepair.exe is not found.
    //This func is called in se_errors_ui.cc::ShowNetworkRescuerButtonOnUIThread.
    $('#button_network').style.display = 'inline-block';
    $('#error_detail').style.display = 'none';
    $('#error_detail_has_netrepair').style.display = '';
}